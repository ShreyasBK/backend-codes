const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    measurer_name: {
        type: String,
        required: true
    },

    process_name: {
        type: String, 
        required: true
    },

    model_name : {
        type:String,
        required:true
    },

    part_serial_name : {
        type:String,
        required:true
    },

    shift : {
        type:String,
        required:true
    },

    machined_surfacepin_journal_od : {
        type:String,
        required:true
    },
    oil_hole_chamfer_area_appearance : {
        type:String,
        required:true
    },

    oil_holes_appearance:     {
        type:String,
        required:true
    },
    cleanliness_machining_surface:{
        type:String,
        required:true
    },

    cleanliness_oil_holes: {
        type:String,
        required:true
    },

    journal_outer_diameter_2_5: {
        type:String,
        required:true
    },
    journal_2_4_width: {
        type:String,
        required:true
    },

    all_pin_outer_diameter: {
        type:String,
        required:true
    },

    all_pin_width: {
        type:String,
        required:true
    },

    pin_width_1_3_counter_weight_side_face_1_5l: {
        type:String,
        required:true
    },
   
    journal_oil_hole_chamfer_diameter:{
        type:String,
        required:true
    },

    pin_oil_hole_chamfer_diameter:  {
        type:String,
        required:true 
    },
    journal_oil_hole_chamfer_width :   {
        type:String,
        required:true
    }
    ,
    pin_oil_hole_chamfer_width :   {
        type:String,
        required:true
    }
    ,
    pin_1_oil_hole_depth_length :   {
        type:String,
        required:true
    }
    ,
    pin_oil_hole_depth_length :   {
        type:String,
        required:true
    }
    ,
    pin_1_end_face_rr_flange_end_face_position :   {
        type:String,
        required:true
    }
    ,
    journal_3_end_face_rr_flange_end_face_position :   {
        type:String,
        required:true
    }
    ,
    pin_2_end_face_position_rr_flange_end_face_position :   {
        type:String,
        required:true
    }
    ,
    journal_3_end_face_rr_flange_end_face_position :   {
        type:String,
        required:true
    }
    ,
    pin_3_end_face_rr_flange_end_face_position :   {
        type:String,
        required:true
    }
    ,
    journal_4_end_face_rr_flange_end_face_position :   {
        type:String,
        required:true
    }
    ,
    pin_position_degree :   {
        type:String,
        required:true
    }
    ,
    journal_2_outer_diameter_runout :   {
        type:String,
        required:true
    }
    ,
    journal_3j_outer_diameter_runout :   {
        type:String,
        required:true
    }
    ,
    journal_4j_outer_diameter_runout :   {
        type:String,
        required:true
    },

    remarksqc2_1_5l:   {
        type:String,
        required:true
    }

})

module.exports = mongoose.model('post_tnga_c_2_1_5ls', PostSchema);