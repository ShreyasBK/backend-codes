const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    measurer_name: {
        type: String,
        required: true
    },

    process_name: {
        type: String, 
        required: true
    },

    model_name : {
        type:String,
        required:true
    },

    part_serial_name : {
        type:String,
        required:true
    },

    shift : {
        type:String,
        required:true
    },

    machining_surface_fr_mounting_screw_hole_pilot_bearing_bore_flywheel_mounting_screw_holes_knock_hole : {
        type:String,
        required:true
    },
    machining_surface_front_axis_od_rr_flange_od_fr_rr_center_holes_pilot_bearing_hole_flywheel_mounting_screw_hole : {
        type:String,
        required:true
    },

    fr_center_hole_contact:     {
        type:String,
        required:true
    },
    fr_mounting_screw_hole_counterbore_diameter_and_depth:{
        type:String,
        required:true
    },

    fr_mounting_screw_pilot_hole_depth: {
        type:String,
        required:true
    },

    fr_mounting_screw_effective_diameter_depth: {
        type:String,
        required:true
    },

    rr_center_hole_contact: {
        type:String,
        required:true
    },

    pilot_bearing_bore_pilot_hole_diameter_and_depth: {
        type:String,
        required:true
    },

    pilot_bearing_hole_depth: {
        type:String,
        required:true
    },
    knock_hole_diameter_depth: {
        type:String,
        required:true
    },

    flywheel_mounting_screw_effective_diameter:{
        type:String,
        required:true
    },

    flywheel_mounting_screw_hole_diameter:  {
        type:String,
        required:true 
    },
    
    pilot_bearing_hole_diameter :   {
        type:String,
        required:true
    }
    ,
    pilot_bearing_hole_roundness :   {
        type:String,
        required:true
    }
    ,
    flywheel_mounting_relative_position_of_pilot_holes :   {
        type:String,
        required:true
    }
    ,

    pilot_bearing_hole_medium_finish_pilot_hole_diameter_depth :   {
        type:String,
        required:true
    }
    ,
    flywheel_mounting_screw_holes_position :   {
        type:String,
        required:true
    }
    ,
    position_of_knock_hole :   {
        type:String,
        required:true
    }
    ,
    fr_center_hole_to_flywheel_mounting_end_face_distance :   {
        type:String,
        required:true
    }
    ,
    rr_center_hole_to_flywheel_mounting_end_face_distance :   {
        type:String,
        required:true
    }
    ,
    pilot_hole_runout :   {
        type:String,
        required:true
    }
    ,
    journal_1_od_runout :   {
        type:String,
        required:true
    }
    ,
    rr_flange_runout :   {
        type:String,
        required:true
    },

    remarksqc4_1_5l:   {
        type:String,
        required:true
    }
    

})

module.exports = mongoose.model('post_tnga_c_4_1_5ls', PostSchema);