const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
measurer_name: { type: String, required : true },
shift: { type: String, required : true },
model_name: { type: String, required : true },
process_name: { type: String, required : true },
part_serial_name: { type: String, required : true },
cleanliness_crank_shaft_whole_appearance: { type: String, required : true },
cleanliness_fr_rr_fitting_hole: { type: String, required : true },
oil_hole_surface: { type: String, required : true },
pin_appearance: { type: String, required : true },
journal_appearance: { type: String, required : true },
rr_flange_appearance: { type: String, required : true },
pin_outer_diameter_1: { type: String, required : true },
pin_outer_diameter_2: { type: String, required : true },
pin_outer_diameter_3: { type: String, required : true },
pin_outer_diameter_4: { type: String, required : true },
pin_outer_diameter_roundness_diameter_method_1: { type: String, required : true },
pin_outer_diameter_roundness_diameter_method_2: { type: String, required : true },
pin_outer_diameter_roundness_diameter_method_3: { type: String, required : true },
pin_outer_diameter_roundness_diameter_method_4: { type: String, required : true },
journal_outer_diameter_1: { type: String, required : true },
journal_outer_diameter_2: { type: String, required : true },
journal_outer_diameter_3: { type: String, required : true },
journal_outer_diameter_4: { type: String, required : true },
journal_outer_diameter_5: { type: String, required : true },
journal_outer_diameter_roundness_diameter_method_1: { type: String, required : true },
journal_outer_diameter_roundness_diameter_method_2: { type: String, required : true },
journal_outer_diameter_roundness_diameter_method_3: { type: String, required : true },
journal_outer_diameter_roundness_diameter_method_4: { type: String, required : true },
journal_outer_diameter_roundness_diameter_method_5: { type: String, required : true },
rr_flange_outer_diameter: { type: String, required : true },
rr_flange_roundness_diameter_method: { type: String, required : true },
rr_flange_outer_diameter_roughness: { type: String, required : true },
remarksqc7_2_0l:   {
    type:String,
    required:true
}
    
})

module.exports = mongoose.model('post_tnga_c_7_2_0ls', PostSchema);