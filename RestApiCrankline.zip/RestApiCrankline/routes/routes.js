const express = require('express');
const router = express.Router();
const Postqc1_1_5l = require('../model/Post_c_1_1_5l');
const Post_c_1_2_0l = require('../model/Post_c_1_2_0l');
const Post_c_2_1_5l = require('../model/Post_c_2_1_5l');
const Post_c_2_2_0l = require('../model/Post_c_2_2_0l');
const Post_c_3_1_5l = require('../model/Post_c_3_1_5l');
const Post_c_3_2_0l = require('../model/Post_c_3_2_0l');
const Post_c_4_1_5l = require('../model/Post_c_4_1_5l');
const Post_c_4_2_0l = require('../model/Post_c_4_2_0l');
const Post_c_5_1_5l = require('../model/Post_c_5_1_5l');
const Post_c_5_2_0l = require('../model/Post_c_5_2_0l');
const Post_c_6_1_5l = require('../model/Post_c_6_1_5l');
const Post_c_6_2_0l = require('../model/Post_c_6_2_0l');
const Post_c_7_1_5l = require('../model/Post_c_7_1_5l');
const Post_c_7_2_0l = require('../model/Post_c_7_2_0l');

const Get = require('../model/Get');


//creating routes


//gets all the posts
// router.get('/', async(req,res) => {
//     try{
//        const posts = await Post.find();
//         res.json(posts);
//         }catch(err){
//         res.json({message:err});
//     }
// });

router.get('/get_tnga_c_qc', async(req,res) => {
    try{
        const limitData = await Get.find();
        res.json(limitData);
        }catch(err){
        res.json({message:err});
    }
   
});


//router.get('/specific', (req,res) => {
  //  res.send('we are on posts');
//});

// Submits all posts

router.post('/tnga_c_1_1_5l', async (req, res) => {
    const post = new Postqc1_1_5l(
    {   
        Measurer_Name:                                                  req.body.Measurer_Name,
        Process_Name:                                                   req.body.Process_Name,
        Model_Name:                                                     req.body.Model_Name,
        Part_Serial_Name:                                               req.body.Part_Serial_Name,
        Shift:                                                          req.body.Shift,
        Serial_number_marking_condition:                                req.body.Serial_number_marking_condition,
        Machining_Surface:                                              req.body.Machining_Surface,
        Circularity_Fr_Rr_center_Hole:                                  req.body.Circularity_Fr_Rr_center_Hole,
        Position_Fr_center_datum_hole:                                  req.body.Position_Fr_center_datum_hole,
        Position_Rr_center_datum_hole:                                  req.body.Position_Rr_center_datum_hole,
        Dia_Fr_Axis_1:                                                  req.body.Dia_Fr_Axis_1,
        Dia_Fr_Axis_2:                                                  req.body.Dia_Fr_Axis_2,
        Dia_FR_axis_groove:                                             req.body.Dia_FR_axis_groove,
        FR_Axis_step_Dia:                                               req.body.FR_Axis_step_Dia,
        J5_Relief_groove_dia:                                           req.body.J5_Relief_groove_dia,
        Rear_flange_width:                                              req.body.Rear_flange_width,
        Fly_wheel_seating_groove_OD:                                    req.body.Fly_wheel_seating_groove_OD,
        Fly_wheel_seating_OD:                                           req.body.Fly_wheel_seating_OD,
        J_1_end_face_position:                                          req.body.J_1_end_face_position,
        J_1_front_face_position:                                        req.body.J_1_front_face_position,
        J_1_RR_side_end_face_position:                                  req.body.J_1_RR_side_end_face_position,
        J1_OD:                                                          req.body.J1_OD,
        Rear_flane_dia:                                                 req.body.Rear_flane_dia,
        Phase_ref_plane_position_datum:                                 req.body.Phase_ref_plane_position_datum,
        Front_face_center_hole_datum_dia_to_part_datum_distance:        req.body.Front_face_center_hole_datum_dia_to_part_datum_distance,
        Rear_face_center_hole_datum_dia_to_part_datum_distance:         req.body.Rear_face_center_hole_datum_dia_to_part_datum_distance,
        FR_end_face_to_FW_fitting_face_length:                          req.body.FR_end_face_to_FW_fitting_face_length,
        Front_shaft_runout_1:                                           req.body.Front_shaft_runout_1,
        Front_shaft_runout_2:                                           req.body.Front_shaft_runout_2,
        FR_axis_step:                                                   req.body.FR_axis_step,
        Journal_1_outer_diameter_runout:                                req.body.Journal_1_outer_diameter_runout,
        RR_axis_runout:                                                 req.body.RR_axis_runout,
        Rr_Flange_outer_diameter_runout:                                req.body.Rr_Flange_outer_diameter_runout,
        Rear_flange_face_runout:                                        req.body.Rear_flange_face_runout,
        J4_OD_runout:                                                   req.body.J4_OD_runout,
        remarksqc1_1_5l:                                                req.body.remarksqc1_1_5l
   
});



    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});


router.post('/tnga_c_1_2_0l', async (req, res) => {
    const post = new Post_c_1_2_0l(
    {   
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        serial_number_marking_condition:                                req.body.serial_number_marking_condition,
        machining_surface:                                              req.body.machining_surface,
        circularity_fr_rr_center_hole:                                  req.body.circularity_fr_rr_center_hole,
        position_fr_center_datum_hole:                                  req.body.position_fr_center_datum_hole,
        position_rr_center_datum_hole:                                  req.body.position_rr_center_datum_hole,
        dia_fr_Axis_1:                                                  req.body.dia_fr_Axis_1,
        dia_fr_Axis_2:                                                  req.body.dia_fr_Axis_2,
        dia_fr_Axis_3:                                                  req.body.dia_fr_Axis_3,
        dia_fr_axis_groove:                                             req.body.dia_fr_axis_groove,
        j5_relief_groove_dia:                                           req.body.j5_relief_groove_dia,
        rear_flange_width:                                              req.body.rear_flange_width,
        fly_wheel_seating_groove_od:                                    req.body.fly_wheel_seating_groove_od,
        fly_wheel_seating_od:                                           req.body.fly_wheel_seating_od,
        j_1_end_face_position_2_0l:                                     req.body.j_1_end_face_position_2_0l,
        j_1_rr_end_face_position_2_0:                                   req.body.j_1_rr_end_face_position_2_0,
        j1_od:                                                          req.body.j1_od,
        rear_flane_dia:                                                 req.body.rear_flane_dia,
        datum_reference_plane_position_k5:                              req.body.datum_reference_plane_position_k5,
        front_face_center_hole_datum_dia_to_part_datum_distance:        req.body.front_face_center_hole_datum_dia_to_part_datum_distance,
        rear_face_center_hole_datum_dia_to_part_datum_distance:         req.body.rear_face_center_hole_datum_dia_to_part_datum_distance,
        fr_end_face_to_fw_fitting_face_length:                          req.body.fr_end_face_to_fw_fitting_face_length,
        front_shaft_runout_k3_1:                                        req.body.front_shaft_runout_k3_1,
        front_shaft_runout_k3_2:                                        req.body.front_shaft_runout_k3_2,
        front_shaft_runout_k3_3:                                        req.body.front_shaft_runout_k3_3,
        journal_1_outer_diameter_runout_k3:                             req.body.journal_1_outer_diameter_runout_k3,
        rr_axis_runout_k3:                                              req.body.rr_axis_runout_k3,
        rr_flange_outer_diameter_runout_k4:                             req.body.rr_flange_outer_diameter_runout_k4,
        rear_flange_face_runout_k6:                                     req.body.rear_flange_face_runout_k6,
        j_5_od_runout_k2:                                               req.body.j_5_od_runout_k2,
        remarksqc1_2_0l:                                                req.body.remarksqc1_2_0l
   
});



    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});


router.post('/tnga_c_2_1_5l', async (req, res) => {
    const post = new Post_c_2_1_5l(
    { 
        measurer_name:                                              req.body.measurer_name,
        process_name:                                               req.body.process_name,
        model_name:                                                 req.body.model_name,
        part_serial_name:                                           req.body.part_serial_name,
        shift:                                                      req.body.shift,
        machined_surfacepin_journal_od                              :req.body.machined_surfacepin_journal_od,
        oil_hole_chamfer_area_appearance                            :req.body.oil_hole_chamfer_area_appearance,
        oil_holes_appearance                                        :req.body.oil_holes_appearance,
        cleanliness_machining_surface                               :req.body.cleanliness_machining_surface,
        cleanliness_oil_holes                                       :req.body.cleanliness_oil_holes,
        journal_outer_diameter_2_5                                  :req.body.journal_outer_diameter_2_5,
        journal_2_4_width                                           :req.body.journal_2_4_width,
        all_pin_outer_diameter                                      :req.body.all_pin_outer_diameter,
        all_pin_width                                               :req.body.all_pin_width,
        pin_width_1_3_counter_weight_side_face_1_5l                 :req.body.pin_width_1_3_counter_weight_side_face_1_5l,
        journal_oil_hole_chamfer_diameter                           :req.body.journal_oil_hole_chamfer_diameter,
        pin_oil_hole_chamfer_diameter                               :req.body.pin_oil_hole_chamfer_diameter,
        journal_oil_hole_chamfer_width                              :req.body.journal_oil_hole_chamfer_width,
        pin_oil_hole_chamfer_width                                  :req.body.pin_oil_hole_chamfer_width,
        pin_1_oil_hole_depth_length                                :req.body.pin_1_oil_hole_depth_length,
        pin_oil_hole_depth_length                                   :req.body.pin_oil_hole_depth_length,
        pin_1_end_face_rr_flange_end_face_position                 :req.body.pin_1_end_face_rr_flange_end_face_position,
        journal_2_end_face_rr_flange_end_face_position             :req.body.journal_2_end_face_rr_flange_end_face_position,
        pin_2_end_face_position_rr_flange_end_face_position        :req.body.pin_2_end_face_position_rr_flange_end_face_position,
        journal_3_end_face_rr_flange_end_face_position             :req.body.journal_3_end_face_rr_flange_end_face_position,
        pin_3_end_face_rr_flange_end_face_position                 :req.body.pin_3_end_face_rr_flange_end_face_position,
        journal_4_end_face_rr_flange_end_face_position             :req.body.journal_4_end_face_rr_flange_end_face_position,
        pin_position_degree                                         :req.body.pin_position_degree,
        journal_2_outer_diameter_runout                            :req.body.journal_2_outer_diameter_runout,
        journal_3j_outer_diameter_runout                           :req.body.journal_3j_outer_diameter_runout,
        journal_4j_outer_diameter_runout                           :req.body.journal_4j_outer_diameter_runout,
        remarksqc2_1_5l:                                                req.body.remarksqc2_1_5l
});

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});


router.post('/tnga_c_2_2_0l', async (req, res) => {
    const post = new Post_c_2_2_0l(
    { 
        measurer_name:req.body.measurer_name,
        process_name:req.body.process_name,
        model_name:req.body.model_name,
        shift:req.body.shift,
        part_serial_name:req.body.part_serial_name,
        machined_surface_pin_journal_od:req.body.machined_surface_pin_journal_od,
        oil_hole_chamfer_area_appearance:req.body.oil_hole_chamfer_area_appearance,
        oil_holes_appearance:req.body.oil_holes_appearance,
        cleanliness_machining_surface:req.body.cleanliness_machining_surface,
        cleanliness_oil_holes:req.body.cleanliness_oil_holes,
        journal_outer_diameter_2_5:req.body.journal_outer_diameter_2_5,
        journal_2_4_width:req.body.journal_2_4_width,
        journal_3_width:req.body.journal_3_width,
        all_pin_outer_diameter:req.body.all_pin_outer_diameter,
        all_pin_width:req.body.all_pin_width,
        journal_oil_hole_chamfer_diameter:req.body.journal_oil_hole_chamfer_diameter,
        pin_oil_hole_chamfer_diameter:req.body.pin_oil_hole_chamfer_diameter,
        journal_oil_hole_chamfer_position:req.body.journal_oil_hole_chamfer_position,
        pin_oil_hole_chamfer_position:req.body.pin_oil_hole_chamfer_position,
        oil_2_4_j_hole_depth_length:req.body.oil_2_4_j_hole_depth_length,
        pin_1_end_face_rr_flange_end_face_position:req.body.pin_1_end_face_rr_flange_end_face_position,
        journal_2_end_face_rr_flange_end_face_position:req.body.journal_2_end_face_rr_flange_end_face_position,
        pin_2_end_face_position_rr_flange_end_face_position:req.body.pin_2_end_face_position_rr_flange_end_face_position,
        journal_3_end_face_rr_flange_end_face_position:req.body.journal_3_end_face_rr_flange_end_face_position,
        pin_3_end_face_rr_flange_end_face_position:req.body.pin_3_end_face_rr_flange_end_face_position,
        journal_4_end_face_rr_flange_end_face_position:req.body.journal_4_end_face_rr_flange_end_face_position,
        pin_4_end_face_rr_flange_end_face_position:req.body.pin_4_end_face_rr_flange_end_face_position,
        journal_5_end_face_rr_flange_end_face_position:req.body.journal_5_end_face_rr_flange_end_face_position,
        pin_position_degree_k2:req.body.pin_position_degree_k2,
        journal_2_outer_diameter_runout_k2:req.body.journal_2_outer_diameter_runout_k2,
        journal_3j_outer_diameter_runout_k2:req.body.journal_3j_outer_diameter_runout_k2,
        journal_4j_outer_diameter_runout_k2:req.body.journal_4j_outer_diameter_runout_k2,
        journal_5j_outer_diameter_runout_k2:req.body.journal_5j_outer_diameter_runout_k2,
        remarksqc2_2_0l:req.body.remarksqc2_2_0l
        

        
  
});

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});

router.post('/tnga_c_3_1_5l', async (req, res) => {
    const post = new Post_c_3_1_5l(
    { 
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        machined_surface_pin_journal                           :req.body.machined_surface_pin_journal,
        j_1_hv_value                                          :req.body.j_1_hv_value,
        j_2_hv_value                                          :req.body.j_2_hv_value,
        j_3_hv_value                                          :req.body.j_3_hv_value,
        j_4_hv_value                                          :req.body.j_4_hv_value,
        pin_1_top_hv_value                                    :req.body.pin_1_top_hv_value,
        pin_2_top_hv_value                                    :req.body.pin_2_top_hv_value,
        pin_3_top_hv_value                                    :req.body.pin_3_top_hv_value,
        pin_1_bottom_hv_value                                 :req.body.pin_1_bottom_hv_value,
        pin_2_bottom_hv_value                                 :req.body.pin_2_bottom_hv_value,
        pin_3_bottom_hv_value                                 :req.body.pin_3_bottom_hv_value,
        journal_2_3_width_1                                   :req.body.journal_2_3_width_1,
        journal_2_3_width_2                                   :req.body.journal_2_3_width_2,
        pin_1_width                                           :req.body.pin_1_width,
        pin_2_width                                           :req.body.pin_2_width,
        pin_3_width                                           :req.body.pin_3_width,
        journal_1st_hardening_range                           :req.body.journal_1st_hardening_range,
        hardening_1_j_range                                   :req.body.hardening_1_j_range,
        hardening_2_j_range                                   :req.body.hardening_2_j_range,
        hardening_3_j_range                                   :req.body.hardening_3_j_range,
        hardening_4_j_range                                   :req.body.hardening_4_j_range,
        journal_4th_non_hardening_range                       :req.body.journal_4th_non_hardening_range,
        hardening_1_p_range                                   :req.body.hardening_1_p_range,
        hardening_2_p_range                                   :req.body.hardening_2_p_range,
        hardening_3_p_range                                   :req.body.hardening_3_p_range,
        journal_1_outer_diameter_runout_after_hardening       :req.body.journal_1_outer_diameter_runout_after_hardening,
        journal_2_outer_diameter_runout_after_hardening       :req.body.journal_2_outer_diameter_runout_after_hardening,
        journal_3_outer_diameter_runout_after_hardening       :req.body.journal_3_outer_diameter_runout_after_hardening,
        journal_4_outer_diameter_runout_after_hardening       :req.body.journal_4_outer_diameter_runout_after_hardening,
        hardening_crack                                        :req.body.hardening_crack,
        remarksqc3_1_5l:                                                req.body.remarksqc3_1_5l
            


        
  
});

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});

router.post('/tnga_c_3_2_0l', async (req, res) => {
    const post = new Post_c_3_2_0l(
    { 
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        machined_surface_pin_journal                            :req.body.machined_surface_pin_journal,
        hv_1_j_value                                           :req.body.hv_1_j_value,
        hv_2_j_value                                           :req.body.hv_2_j_value,
        hv_3_j_value                                           :req.body.hv_3_j_value,
        hv_4_j_value                                           :req.body.hv_4_j_value,
        hv_5_j_value                                           :req.body.hv_5_j_value,
        pin_1_top_hv_value                                     :req.body.pin_1_top_hv_value,
        pin_2_top_hv_value                                     :req.body.pin_2_top_hv_value,
        pin_3_top_hv_value                                     :req.body.pin_3_top_hv_value,
        pin_4_top_hv_value                                     :req.body.pin_4_top_hv_value,
        pin_1_bottom_hv_value                                  :req.body.pin_1_bottom_hv_value,
        pin_2_bottom_hv_value                                  :req.body.pin_2_bottom_hv_value,
        pin_3_bottom_hv_value                                  :req.body.pin_3_bottom_hv_value,
        pin_4_bottom_hv_value                                  :req.body.pin_4_bottom_hv_value,
        journal_2_4_width_1                                    :req.body.journal_2_4_width_1,
        journal_2_4_width_2                                    :req.body.journal_2_4_width_2,
        journal_3_width                                        :req.body.journal_3_width,
        pin_1_width                                            :req.body.pin_1_width,
        pin_2_width                                            :req.body.pin_2_width,
        pin_3_width                                            :req.body.pin_3_width,
        pin_4_width                                            :req.body.pin_4_width,
        journal_1st_hardening_range                           :req.body.journal_1st_hardening_range,
        hardening_1_j_range                                    :req.body.hardening_1_j_range,
        hardening_2_j_range                                    :req.body.hardening_2_j_range,
        hardening_3_j_range                                    :req.body.hardening_3_j_range,
        hardening_4_j_range                                    :req.body.hardening_4_j_range,
        hardening_5_j_range                                    :req.body.hardening_5_j_range,
        journal_5th_non_hardening_range                        :req.body.journal_5th_non_hardening_range,
        hardening_1_p_range                                    :req.body.hardening_1_p_range,
        hardening_2_p_range                                    :req.body.hardening_2_p_range,
        hardening_3_p_range                                    :req.body.hardening_3_p_range,
        hardening_4_p_range                                    :req.body.hardening_4_p_range,
        journal_1_outer_diameter_runout_after_hardening        :req.body.journal_1_outer_diameter_runout_after_hardening,
        journal_2_outer_diameter_runout_after_hardening        :req.body.journal_2_outer_diameter_runout_after_hardening,
        journal_3_outer_diameter_runout_after_hardening        :req.body.journal_3_outer_diameter_runout_after_hardening,
        journal_4_outer_diameter_runout_after_hardening        :req.body.journal_4_outer_diameter_runout_after_hardening,
        journal_5_outer_diameter_runout_after_hardening        :req.body.journal_5_outer_diameter_runout_after_hardening,
        hardening_crack                                         :req.body.hardening_crack,
        remarksqc3_2_0l:                                                req.body.remarksqc3_2_0l
           


        
  
});

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});

router.post('/tnga_c_4_1_5l', async (req, res) => {
    const post = new Post_c_4_1_5l(
    { 
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        machining_surface_fr_mounting_screw_hole_pilot_bearing_bore_flywheel_mounting_screw_holes_knock_hole: req.body.machining_surface_fr_mounting_screw_hole_pilot_bearing_bore_flywheel_mounting_screw_holes_knock_hole,
        machining_surface_front_axis_od_rr_flange_od_fr_rr_center_holes_pilot_bearing_hole_flywheel_mounting_screw_hole:req.body.machining_surface_front_axis_od_rr_flange_od_fr_rr_center_holes_pilot_bearing_hole_flywheel_mounting_screw_hole,
        fr_center_hole_contact                                             :req.body.fr_center_hole_contact,
        fr_mounting_screw_hole_counterbore_diameter_and_depth              :req.body.fr_mounting_screw_hole_counterbore_diameter_and_depth,
        fr_mounting_screw_pilot_hole_depth                                 :req.body.fr_mounting_screw_pilot_hole_depth,
        fr_mounting_screw_effective_diameter_depth                         :req.body.fr_mounting_screw_effective_diameter_depth,
        knock_hole_diameter_depth                                          :req.body.knock_hole_diameter_depth,
        rr_center_hole_contact                                             :req.body.rr_center_hole_contact,
        pilot_bearing_bore_pilot_hole_diameter_and_depth                   :req.body.pilot_bearing_bore_pilot_hole_diameter_and_depth,
        pilot_bearing_hole_depth                                           :req.body.pilot_bearing_hole_depth,
        flywheel_mounting_screw_hole_diameter                              :req.body.flywheel_mounting_screw_hole_diameter,
        flywheel_mounting_screw_effective_diameter                         :req.body.flywheel_mounting_screw_effective_diameter,
        flywheel_mounting_relative_position_of_pilot_holes                 :req.body.flywheel_mounting_relative_position_of_pilot_holes,
        pilot_bearing_hole_diameter                                        :req.body.pilot_bearing_hole_diameter,
        pilot_bearing_hole_roundness                                       :req.body.pilot_bearing_hole_roundness,
        pilot_bearing_hole_medium_finish_pilot_hole_diameter_depth         :req.body.pilot_bearing_hole_medium_finish_pilot_hole_diameter_depth,
        flywheel_mounting_screw_holes_position                             :req.body.flywheel_mounting_screw_holes_position,
        position_of_knock_hole                                             :req.body.position_of_knock_hole,
        fr_center_hole_to_flywheel_mounting_end_face_distance              :req.body.fr_center_hole_to_flywheel_mounting_end_face_distance,
        rr_center_hole_to_flywheel_mounting_end_face_distance              :req.body.rr_center_hole_to_flywheel_mounting_end_face_distance,
        pilot_hole_runout                                                  :req.body.pilot_hole_runout,
        journal_1_od_runout                                                :req.body.journal_1_od_runout,
        rr_flange_runout                                                   :req.body.rr_flange_runout,   
        remarksqc4_1_5l:                                                req.body.remarksqc4_1_5l


});

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});
router.post('/tnga_c_4_2_0l', async (req, res) => {
    const post = new Post_c_4_2_0l(
    { 
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        machining_surface_fr_mounting_screw_hole_pilot_bearing_bore_flywheel_mounting_screw_holes_knock_hole:req.body.machining_surface_fr_mounting_screw_hole_pilot_bearing_bore_flywheel_mounting_screw_holes_knock_hole ,
        machining_surface_front_axis_od_rr_flange_od_fr_rr_center_holes_pilot_bearing_hole_flywheel_mounting_screw_hole:req.body.machining_surface_front_axis_od_rr_flange_od_fr_rr_center_holes_pilot_bearing_hole_flywheel_mounting_screw_hole,
        fr_center_hole_contact                                      :req.body.fr_center_hole_contact,
        fr_mounting_screw_hole_counterbore_diameter_and_depth       :req.body.fr_mounting_screw_hole_counterbore_diameter_and_depth,
        fr_mounting_screw_pilot_hole_depth                          :req.body.fr_mounting_screw_pilot_hole_depth,
        fr_mounting_screw_effective_diameter_depth                  :req.body.fr_mounting_screw_effective_diameter_depth,
        knock_hole_diameter_depth                                   :req.body.knock_hole_diameter_depth,
        rr_center_hole_contact                                      :req.body.rr_center_hole_contact,
        pilot_bearing_bore_pilot_hole_diameter_and_depth            :req.body.pilot_bearing_bore_pilot_hole_diameter_and_depth,
        pilot_bearing_hole_depth                                    :req.body.pilot_bearing_hole_depth,
        flywheel_mounting_screw_hole_diameter                       :req.body.flywheel_mounting_screw_hole_diameter,
        flywheel_mounting_screw_effective_diameter                  :req.body.flywheel_mounting_screw_effective_diameter,
        flywheel_mounting_relative_position_of_pilot_holes          :req.body.flywheel_mounting_relative_position_of_pilot_holes,
        pilot_bearing_hole_diameter                                 :req.body.pilot_bearing_hole_diameter,
        pilot_bearing_hole_roundness                                :req.body.pilot_bearing_hole_roundness,
        pilot_bearing_hole_medium_finish_pilot_hole_diameter_depth  :req.body.pilot_bearing_hole_medium_finish_pilot_hole_diameter_depth,
        flywheel_mounting_screw_holes_position                      :req.body.flywheel_mounting_screw_holes_position,
        position_of_knock_hole                                      :req.body.position_of_knock_hole,
        fr_center_hole_to_flywheel_mounting_end_face_distance       :req.body.fr_center_hole_to_flywheel_mounting_end_face_distance,
        rr_center_hole_to_flywheel_mounting_end_face_distance       :req.body.rr_center_hole_to_flywheel_mounting_end_face_distance,
        pilot_hole_runout                                           :req.body.pilot_hole_runout,
        journal_1_od_runout                                        :req.body.journal_1_od_runout,
        rr_flange_runout                                            :req.body.rr_flange_runout,
        remarksqc4_2_0l:                                                req.body.remarksqc4_2_0l


    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});
        
router.post('/tnga_c_5_1_5l', async (req, res) => {
    const post = new Post_c_5_1_5l(
    { 
        measurer_name:req.body.measurer_name,
        shift:req.body.shift,
        model_name:req.body.model_name,
        process_name:req.body.process_name,
        part_serial_name:req.body.part_serial_name,
        front_axis_machining_surface:req.body.front_axis_machining_surface,
        thrust_face_appearance:req.body.thrust_face_appearance,
        pin_surface:req.body.pin_surface,
        pin_corner_radius:req.body.pin_corner_radius,
        journal_surface:req.body.journal_surface,
        journal_corner_radius:req.body.journal_corner_radius,
        rear_flange_machining_surface:req.body.rear_flange_machining_surface,
        front_axis_end_face_thrust_end_face_position_1_5l:req.body.front_axis_end_face_thrust_end_face_position_1_5l,
        rr_flange_end_face_thrust_end_face_position_1_5l:req.body.rr_flange_end_face_thrust_end_face_position_1_5l,
        thrust_width_1_5l_1:req.body.thrust_width_1_5l_1,
        thrust_r_position_1_5l:req.body.thrust_r_position_1_5l,
        journal_oil_hole_chamfer_base_distribution:req.body.journal_oil_hole_chamfer_base_distribution,
        land_width_b_w_oil_hole_chamfer_and_the_pin_sid_face_common:req.body.land_width_b_w_oil_hole_chamfer_and_the_pin_sid_face_common,
        thrust_width_1_5l_2:req.body.thrust_width_1_5l_2,
        pin_1_outer_diameter:req.body.pin_1_outer_diameter,
        pin_2_outer_diameter:req.body.pin_2_outer_diameter,
        pin_3_outer_diameter:req.body.pin_3_outer_diameter,
        pin_1_roundness:req.body.pin_1_roundness,
        pin_2_roundness:req.body.pin_2_roundness,
        pin_3_roundness:req.body.pin_3_roundness,
        journal_1_outer_diameter:req.body.journal_1_outer_diameter,
        journal_2_outer_diameter:req.body.journal_2_outer_diameter,
        journal_3_outer_diameter:req.body.journal_3_outer_diameter,
        journal_4_outer_diameter:req.body.journal_4_outer_diameter,
        journal_1_roundness:req.body.journal_1_roundness,
        journal_2_roundness:req.body.journal_2_roundness,
        journal_3_roundness:req.body.journal_3_roundness,
        journal_4_roundness:req.body.journal_4_roundness,
        rr_flange_outer_diameter:req.body.rr_flange_outer_diameter,
        rr_flange_roundness:req.body.rr_flange_roundness,
        pin_straightness_hit_without_fading:req.body.pin_straightness_hit_without_fading,
        one_5l_1j_2j_and_4j:req.body.one_5l_1j_2j_and_4j,
        journal_3rd_straightness:req.body.journal_3rd_straightness,
        front_axis_outer_diameter:req.body.front_axis_outer_diameter,
        front_axis_roundness:req.body.front_axis_roundness,
        flyweel_mounting_boss_outer_diameter:req.body.flyweel_mounting_boss_outer_diameter,
        front_axis_end_face_plane_check:req.body.front_axis_end_face_plane_check,
        rr_flange_end_face_plane_check:req.body.rr_flange_end_face_plane_check,
        front_axis_outer_diameter_runout_with_center:req.body.front_axis_outer_diameter_runout_with_center,
        journal_1_outer_diameter_runout_with_center:req.body.journal_1_outer_diameter_runout_with_center,
        journal_2_outer_diameter_runout_with_center:req.body.journal_2_outer_diameter_runout_with_center,
        journals_3_outer_diameter_runout_with_center:req.body.journals_3_outer_diameter_runout_with_center,
        journals_4_outer_diameter_runout_with_center:req.body.journals_4_outer_diameter_runout_with_center,
        rr_flange_outer_diameter_runout_with_center:req.body.rr_flange_outer_diameter_runout_with_center,
        rr_boss_runout_with_center:req.body.rr_boss_runout_with_center,
        front_axis_end_face_runout_with_center:req.body.front_axis_end_face_runout_with_center,
        front_shaft_end_face_perpendicualrity_with_center:req.body.front_shaft_end_face_perpendicualrity_with_center,
        thrust_end_face_runout_with_center:req.body.thrust_end_face_runout_with_center,
        thrust_end_face_perpendicularity_with_center:req.body.thrust_end_face_perpendicularity_with_center,
        rr_flange_end_face_perpendicularity_with_center_and_common:req.body.rr_flange_end_face_perpendicularity_with_center_and_common,
        pin_1_position_with_center:req.body.pin_1_position_with_center,
        pin_2_position_with_center:req.body.pin_2_position_with_center,
        pin_3_position_with_center:req.body.pin_3_position_with_center,
        pin_1_parallelism_with_center:req.body.pin_1_parallelism_with_center,
        pin_2_parallelism_with_center:req.body.pin_2_parallelism_with_center,
        pin_3_parallelism_with_center:req.body.pin_3_parallelism_with_center,
        pin_1_1_2_stroke_with_center:req.body.pin_1_1_2_stroke_with_center,
        pin_2_1_2_stroke_with_center:req.body.pin_2_1_2_stroke_with_center,
        pin_3_1_2_stroke_with_center:req.body.pin_3_1_2_stroke_with_center,
        fr_axis_runout_without_center:req.body.fr_axis_runout_without_center,
        rr_flange_axis_runout_without_center:req.body.rr_flange_axis_runout_without_center,
        rr_flywheel_axis_od_runout_without_center:req.body.rr_flywheel_axis_od_runout_without_center,
        pin_1_position_without_center:req.body.pin_1_position_without_center,
        pin_2_position_without_center:req.body.pin_2_position_without_center,
        pin_3_position_without_center:req.body.pin_3_position_without_center,
        pin_4_position_without_center:req.body.pin_4_position_without_center,
        pin_1_parallelism_without_center:req.body.pin_1_parallelism_without_center,
        pin_2_parallelism_without_center:req.body.pin_2_parallelism_without_center,
        pin_3_parallelism_without_center:req.body.pin_3_parallelism_without_center,
        pin_4_parallelism_without_center:req.body.pin_4_parallelism_without_center,
        pin_1_1_2_stroke_without_center:req.body.pin_1_1_2_stroke_without_center,
        pin_2_1_2_stroke_without_center:req.body.pin_2_1_2_stroke_without_center,
        pin_3_1_2_stroke_without_center:req.body.pin_3_1_2_stroke_without_center,
        pin_4_1_2_stroke_without_center:req.body.pin_4_1_2_stroke_without_center,
        rr_flange_outer_diameter_roughness:req.body.rr_flange_outer_diameter_roughness,
        pin_1_surface_hardness:req.body.pin_1_surface_hardness,
        pin_2_surface_hardness:req.body.pin_2_surface_hardness,
        pin_3_surface_hardness:req.body.pin_3_surface_hardness,
        pin_4_surface_hardness:req.body.pin_4_surface_hardness,
        journal_1_surface_hardness:req.body.journal_1_surface_hardness,
        journal_2_surface_hardness:req.body.journal_2_surface_hardness,
        journal_3_surface_hardness:req.body.journal_3_surface_hardness,
        journal_4_surface_hardness:req.body.journal_4_surface_hardness,
        journal_5_surface_hardness:req.body.journal_5_surface_hardness,
        pin_journal_grinding_crack:req.body.pin_journal_grinding_crack,
        remarksqc5_1_5l:                                                req.body.remarksqc5_1_5l

    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});

    
router.post('/tnga_c_5_2_0l', async (req, res) => {
    const post = new Post_c_5_2_0l(
    { 
        measurer_name:req.body.measurer_name,
        shift:req.body.shift,
        model_name:req.body.model_name,
        process_name:req.body.process_name,
        part_serial_name:req.body.part_serial_name,
        front_axis_and_face:req.body.front_axis_and_face,
        thrust_face_appearance:req.body.thrust_face_appearance,
        pin_surface:req.body.pin_surface,
        pin_corner_radius:req.body.pin_corner_radius,
        journal_surface:req.body.journal_surface,
        journal_corner_radius:req.body.journal_corner_radius,
        rear_flange_rear_axis_machining_surface:req.body.rear_flange_rear_axis_machining_surface,
        front_shaft_end_face_thrust_end_face_position:req.body.front_shaft_end_face_thrust_end_face_position,
        rr_flange_end_face_thrust_end_face_position:req.body.rr_flange_end_face_thrust_end_face_position,
        thrust_width_thrust_r_position:req.body.thrust_width_thrust_r_position,
        journal_oil_hole_chamfer_base_distribution:req.body.journal_oil_hole_chamfer_base_distribution,
        land_width_b_w_oil_hole_chamfer_the_pin_sid_face:req.body.land_width_b_w_oil_hole_chamfer_the_pin_sid_face,
        thrust_width:req.body.thrust_width,
        pin_1_outer_diameter:req.body.pin_1_outer_diameter,
        pin_2_outer_diameter:req.body.pin_2_outer_diameter,
        pin_3_outer_diameter:req.body.pin_3_outer_diameter,
        pin_4_outer_diameter:req.body.pin_4_outer_diameter,
        pin_1_roundness:req.body.pin_1_roundness,
        pin_2_roundness:req.body.pin_2_roundness,
        pin_3_roundness:req.body.pin_3_roundness,
        pin_4_roundness:req.body.pin_4_roundness,
        journal_1_outer_diameter:req.body.journal_1_outer_diameter,
        journal_2_outer_diameter:req.body.journal_2_outer_diameter,
        journal_3_outer_diameter:req.body.journal_3_outer_diameter,
        journal_4_outer_diameter:req.body.journal_4_outer_diameter,
        journal_5_outer_diameter:req.body.journal_5_outer_diameter,
        journal_1_roundness:req.body.journal_1_roundness,
        journal_2_roundness:req.body.journal_2_roundness,
        journal_3_roundness:req.body.journal_3_roundness,
        journal_4_roundness:req.body.journal_4_roundness,
        journal_5_roundness:req.body.journal_5_roundness,
        rr_flange_outer_diameter:req.body.rr_flange_outer_diameter,
        rr_flange_roundness:req.body.rr_flange_roundness,
        all_pin_straightness:req.body.all_pin_straightness,
        straightness_1_5l_1j_2j_4j_2l_1j_2j_4j_5j:req.body.straightness_1_5l_1j_2j_4j_2l_1j_2j_4j_5j,
        journal_3rd_straightness:req.body.journal_3rd_straightness,
        front_axis_outer_diameter:req.body.front_axis_outer_diameter,
        front_axis_roundness_common:req.body.front_axis_roundness_common,
        flyweel_mounting_boss_outer_diameter:req.body.flyweel_mounting_boss_outer_diameter,
        flyweel_mounting_boss_roundness:req.body.flyweel_mounting_boss_roundness,
        front_axis_end_face_plane_check:req.body.front_axis_end_face_plane_check,
        rr_flange_end_face_plane_check:req.body.rr_flange_end_face_plane_check,
        front_axis_outer_diameter_runout_with_center_k10:req.body.front_axis_outer_diameter_runout_with_center_k10,
        journal_1_outer_diameter_runout_with_center_k10:req.body.journal_1_outer_diameter_runout_with_center_k10,
        journal_2_outer_diameter_runout_with_center_k10:req.body.journal_2_outer_diameter_runout_with_center_k10,
        journals_3_outer_diameter_runout_with_center_k10:req.body.journals_3_outer_diameter_runout_with_center_k10,
        journals_4_outer_diameter_runout_with_center_k10:req.body.journals_4_outer_diameter_runout_with_center_k10,
        journals_5_outer_diameter_runout_with_center_k10:req.body.journals_5_outer_diameter_runout_with_center_k10,
        rr_flange_outer_diameter_runout_with_center_k10:req.body.rr_flange_outer_diameter_runout_with_center_k10,
        rr_boss_runout_with_center_k10:req.body.rr_boss_runout_with_center_k10,
        front_axis_end_face_runout_with_center_k11:req.body.front_axis_end_face_runout_with_center_k11,
        front_shaft_end_face_perpendicualrity_with_center_k11:req.body.front_shaft_end_face_perpendicualrity_with_center_k11,
        thrust_end_face_runout_with_center_k11:req.body.thrust_end_face_runout_with_center_k11,
        thrust_end_face_perpendicularity_with_center_k11:req.body.thrust_end_face_perpendicularity_with_center_k11,
        rr_flange_end_face_perpendicularity_with_center_k11:req.body.rr_flange_end_face_perpendicularity_with_center_k11,
        pin_1_position_with_center_k8:req.body.pin_1_position_with_center_k8,
        pin_2_position_with_center_k7:req.body.pin_2_position_with_center_k7,
        pin_3_position_eith_center_k7:req.body.pin_3_position_eith_center_k7,
        pin_4_position_with_center_k8:req.body.pin_4_position_with_center_k8,
        pin_1_parallelism_with_center_k9:req.body.pin_1_parallelism_with_center_k9,
        pin_2_parallelism_with_center_k9:req.body.pin_2_parallelism_with_center_k9,
        pin_3_parallelism_with_center_k9:req.body.pin_3_parallelism_with_center_k9,
        pin_4_parallelism_with_center_k9:req.body.pin_4_parallelism_with_center_k9,
        pin_1_1_2_stroke_with_center_k9:req.body.pin_1_1_2_stroke_with_center_k9,
        pin_2_1_2_stroke_with_center_k9:req.body.pin_2_1_2_stroke_with_center_k9,
        pin_3_1_2_stroke_with_center_k9:req.body.pin_3_1_2_stroke_with_center_k9,
        pin_4_1_2_stroke_with_center_k10:req.body.pin_4_1_2_stroke_with_center_k10,
        fr_axis_runout_without_center_k10:req.body.fr_axis_runout_without_center_k10,
        runout_2j_without_center_k10:req.body.runout_2j_without_center_k10,
        runout_3j_without_center_k10:req.body.runout_3j_without_center_k10,
        runout_4j_without_center_k10:req.body.runout_4j_without_center_k10,
        rr_axis_runout_without_center_k10:req.body.rr_axis_runout_without_center_k10,
        rr_flywheel_axis_od_runout_without_center_k10:req.body.rr_flywheel_axis_od_runout_without_center_k10,
        rr_flywheel_perpendicularity_without_center_k10:req.body.rr_flywheel_perpendicularity_without_center_k10,
        pin_1_position_without_center_k8:req.body.pin_1_position_without_center_k8,
        pin_2_position_without_center_k7:req.body.pin_2_position_without_center_k7,
        pin_3_position_without_center_k7:req.body.pin_3_position_without_center_k7,
        pin_4_position_without_center_k8:req.body.pin_4_position_without_center_k8,
        pin_1_parallelism_without_center_k9:req.body.pin_1_parallelism_without_center_k9,
        pin_2_parallelism_without_center_k9:req.body.pin_2_parallelism_without_center_k9,
        pin_3_parallelism_without_center_k9:req.body.pin_3_parallelism_without_center_k9,
        pin_4_parallelism_without_center_k9:req.body.pin_4_parallelism_without_center_k9,
        pin_1_1_2_stroke_without_center_k9:req.body.pin_1_1_2_stroke_without_center_k9,
        pin_2_1_2_stroke_without_center_k9:req.body.pin_2_1_2_stroke_without_center_k9,
        pin_3_1_2_stroke_without_center_k9:req.body.pin_3_1_2_stroke_without_center_k9,
        pin_4_1_2_stroke_without_center_k9:req.body.pin_4_1_2_stroke_without_center_k9,
        rr_flange_outer_diameter_roughness_k10:req.body.rr_flange_outer_diameter_roughness_k10,
        pin_1_surface_hardness:req.body.pin_1_surface_hardness,
        pin_2_surface_hardness:req.body.pin_2_surface_hardness,
        pin_3_surface_hardness:req.body.pin_3_surface_hardness,
        pin_4_surface_hardness:req.body.pin_4_surface_hardness,
        journal_1_surface_hardness:req.body.journal_1_surface_hardness,
        journal_2_surface_hardness:req.body.journal_2_surface_hardness,
        journal_3_surface_hardness:req.body.journal_3_surface_hardness,
        journal_4_surface_hardness:req.body.journal_4_surface_hardness,
        journal_5_surface_hardness:req.body.journal_5_surface_hardness,
        pin_journal_grinding_crack:req.body.pin_journal_grinding_crack,
        remarksqc5_2_0l:                                                req.body.remarksqc5_2_0l

        
    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});

router.post('/tnga_c_6_1_5l', async (req, res) => {
    const post = new Post_c_6_1_5l(
    { 
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        balance_correction_hole_appearance                   :req.body.balance_correction_hole_appearance,
        keyway_chamfer                                       :req.body.keyway_chamfer,
        key_surface                                          :req.body.key_surface,
        keyway_width                                         :req.body.keyway_width,
        key_groove_depth                                     :req.body.key_groove_depth,
        key_groove_position                                  :req.body.key_groove_position,
        keyway_parallelism                                   :req.body.keyway_parallelism,
        key_press_fitting_surface                            :req.body.key_press_fitting_surface,
        knock_pin_surface                                    :req.body.knock_pin_surface,
        knock_pin_press_fitting_surface                      :req.body.knock_pin_press_fitting_surface,
        key_press_height                                     :req.body.key_press_height,
        knock_pin_press_fit_height                           :req.body.knock_pin_press_fit_height,
        remarksqc6_1_5l:                                                req.body.remarksqc6_1_5l

        
    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});

router.post('/tnga_c_6_2_0l', async (req, res) => {
    const post = new Post_c_6_2_0l(
    { 
        measurer_name:                                                  req.body.measurer_name,
        process_name:                                                   req.body.process_name,
        model_name:                                                     req.body.model_name,
        part_serial_name:                                               req.body.part_serial_name,
        shift:                                                          req.body.shift,
        balance_correction_hole_appearance          :req.body.balance_correction_hole_appearance,
        keyway_chamfer                              :req.body.keyway_chamfer,
        key_surface                                 :req.body.key_surface,
        keyway_width_1                                :req.body.keyway_width_1,
        keyway_width_2                                :req.body.keyway_width_2,
        key_1_groove_depth                         :req.body.key_1_groove_depth,
        key_2_groove_depth                         :req.body.key_2_groove_depth,
        key_1_groove_position                      :req.body.key_1_groove_position,
        key_2_groove_position                      :req.body.key_2_groove_position,
        keyway_1_parallelism                       :req.body.keyway_1_parallelism,
        keyway_2_parallelism                       :req.body.keyway_2_parallelism,
        keyway_relative_position                    :req.body.keyway_relative_position,
        key_press_fitting_surface                   :req.body.key_press_fitting_surface,
        knock_pin_surface                           :req.body.knock_pin_surface,
        knock_pin_press_fitting_surface             :req.body.knock_pin_press_fitting_surface,
        key_press_height_1                            :req.body.key_press_height_1,
        key_press_height_2                            :req.body.key_press_height_2,
        knock_pin_press_fit_height                  :req.body.knock_pin_press_fit_height,
        remarksqc6_2_0l:                                                req.body.remarksqc6_2_0l
        
    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});


router.post('/tnga_c_7_1_5l', async (req, res) => {
    const post = new Post_c_7_1_5l(
    { 
        measurer_name:req.body.measurer_name,					
        shift:req.body.shift,					
        model_name:req.body.model_name,					
        process_name:req.body.process_name,					
        part_serial_name:req.body.part_serial_name,					
        cleanliness_crankshaft_whole_appearance:req.body.cleanliness_crankshaft_whole_appearance,					
        cleanliness_fr_rr_fitting_hole:req.body.cleanliness_fr_rr_fitting_hole,					
        oil_hole_surface:req.body.oil_hole_surface,					
        pin_appearance:req.body.pin_appearance,					
        journal_appearance:req.body.journal_appearance,					
        rr_flange_appearance:req.body.rr_flange_appearance,					
        pin_outer_diameter_1:req.body.pin_outer_diameter_1,					
        pin_outer_diameter_2:req.body.pin_outer_diameter_2,					
        pin_outer_diameter_3:req.body.pin_outer_diameter_3,					
        pin_outer_diameter_roundness_diameter_method_1:req.body.pin_outer_diameter_roundness_diameter_method_1,					
        pin_outer_diameter_roundness_diameter_method_2:req.body.pin_outer_diameter_roundness_diameter_method_2,					
        pin_outer_diameter_roundness_diameter_method_3:req.body.pin_outer_diameter_roundness_diameter_method_3,					
        journal_outer_diameter_1:req.body.journal_outer_diameter_1,					
        journal_outer_diameter_2:req.body.journal_outer_diameter_2,					
        journal_outer_diameter_3:req.body.journal_outer_diameter_3,					
        journal_outer_diameter_4:req.body.journal_outer_diameter_4,					
        journal_outer_diameter_roundness_diameter_method_1:req.body.journal_outer_diameter_roundness_diameter_method_1,					
        journal_outer_diameter_roundness_diameter_method_2:req.body.journal_outer_diameter_roundness_diameter_method_2,					
        journal_outer_diameter_roundness_diameter_method_3:req.body.journal_outer_diameter_roundness_diameter_method_3,					
        journal_outer_diameter_roundness_diameter_method_4:req.body.journal_outer_diameter_roundness_diameter_method_4,					
        rr_flange_outer_diameter:req.body.rr_flange_outer_diameter,					
        rr_flange_roundness_diameter_method:req.body.rr_flange_roundness_diameter_method,					
        rr_flange_outer_diameter_roughness:req.body.rr_flange_outer_diameter_roughness,	
        remarksqc7_1_5l:                                                req.body.remarksqc7_1_5l				
        


    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});








router.post('/tnga_c_7_2_0l', async (req, res) => {
    const post = new Post_c_7_2_0l(
    { 
        measurer_name:req.body.measurer_name,
        shift:req.body.shift,
        model_name:req.body.model_name,
        process_name:req.body.process_name,
        part_serial_name:req.body.part_serial_name,
        cleanliness_crank_shaft_whole_appearance:req.body.cleanliness_crank_shaft_whole_appearance,
        cleanliness_fr_rr_fitting_hole:req.body.cleanliness_fr_rr_fitting_hole,
        oil_hole_surface:req.body.oil_hole_surface,
        pin_appearance:req.body.pin_appearance,
        journal_appearance:req.body.journal_appearance,
        rr_flange_appearance:req.body.rr_flange_appearance,
        pin_outer_diameter_1:req.body.pin_outer_diameter_1,
        pin_outer_diameter_2:req.body.pin_outer_diameter_2,
        pin_outer_diameter_3:req.body.pin_outer_diameter_3,
        pin_outer_diameter_4:req.body.pin_outer_diameter_4,
        pin_outer_diameter_roundness_diameter_method_1:req.body.pin_outer_diameter_roundness_diameter_method_1,
        pin_outer_diameter_roundness_diameter_method_2:req.body.pin_outer_diameter_roundness_diameter_method_2,
        pin_outer_diameter_roundness_diameter_method_3:req.body.pin_outer_diameter_roundness_diameter_method_3,
        pin_outer_diameter_roundness_diameter_method_4:req.body.pin_outer_diameter_roundness_diameter_method_4,
        journal_outer_diameter_1:req.body.journal_outer_diameter_1,
        journal_outer_diameter_2:req.body.journal_outer_diameter_2,
        journal_outer_diameter_3:req.body.journal_outer_diameter_3,
        journal_outer_diameter_4:req.body.journal_outer_diameter_4,
        journal_outer_diameter_5:req.body.journal_outer_diameter_5,
        journal_outer_diameter_roundness_diameter_method_1:req.body.journal_outer_diameter_roundness_diameter_method_1,
        journal_outer_diameter_roundness_diameter_method_2:req.body.journal_outer_diameter_roundness_diameter_method_2,
        journal_outer_diameter_roundness_diameter_method_3:req.body.journal_outer_diameter_roundness_diameter_method_3,
        journal_outer_diameter_roundness_diameter_method_4:req.body.journal_outer_diameter_roundness_diameter_method_4,
        journal_outer_diameter_roundness_diameter_method_5:req.body.journal_outer_diameter_roundness_diameter_method_5,
        rr_flange_outer_diameter:req.body.rr_flange_outer_diameter,
        rr_flange_roundness_diameter_method:req.body.rr_flange_roundness_diameter_method,
        rr_flange_outer_diameter_roughness:req.body.rr_flange_outer_diameter_roughness,
        remarksqc7_2_0l:                                                req.body.remarksqc7_2_0l
        
        

    });

    try{
    const savedPost = await post.save()
    res.json(savedpost);
    }
    catch(err){
        res.json({message:err})
    }
});


module.exports = router;


