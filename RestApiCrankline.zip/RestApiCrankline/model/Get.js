const mongoose = require("mongoose");

const getSchema  = mongoose.Schema({

    
})

module.exports = mongoose.model('tnga_crankline_qc_apps', getSchema);