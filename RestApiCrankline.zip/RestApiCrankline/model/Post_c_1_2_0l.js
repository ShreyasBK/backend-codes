const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    measurer_name: {
        type: String,
        required: true
    },

    process_name: {
        type: String, 
        required: true
    },

    model_name : {
        type:String,
        required:true
    },

    part_serial_name : {
        type:String,
        required:true
    },

    shift : {
        type:String,
        required:true
    },

    serial_number_marking_condition : {
        type:String,
        required:true
    },
    machining_surface : {
        type:String,
        required:true
    },

    position_fr_center_datum_hole:     {
        type:String,
        required:true
    },
    position_rr_center_datum_hole:{
        type:String,
        required:true
    },

    dia_fr_Axis_1: {
        type:String,
        required:true
    },

    dia_fr_Axis_2: {
        type:String,
        required:true
    },
    dia_fr_Axis_3: {
        type:String,
        required:true
    },


    dia_fr_axis_groove: {
        type:String,
        required:true
    },

    j5_relief_groove_dia: {
        type:String,
        required:true
    },

    rear_flange_width: {
        type:String,
        required:true
    },
   
    fly_wheel_seating_groove_od:{
        type:String,
        required:true
    },

    fly_wheel_seating_od:  {
        type:String,
        required:true 
    },
    j_1_end_face_position_2_0l :   {
        type:String,
        required:true
    }
    ,
    j_1_rr_end_face_position_2_0 :   {
        type:String,
        required:true
    }
    ,
    j1_od :   {
        type:String,
        required:true
    }
    ,
    rear_flane_dia :   {
        type:String,
        required:true
    }
    ,
    datum_reference_plane_position_k5 :   {
        type:String,
        required:true
    }
    ,
    front_face_center_hole_datum_dia_to_part_datum_distance :   {
        type:String,
        required:true
    }
    ,
    rear_face_center_hole_datum_dia_to_part_datum_distance :   {
        type:String,
        required:true
    }
    ,
    fr_end_face_to_fw_fitting_face_length :   {
        type:String,
        required:true
    }
    ,
    front_shaft_runout_k3_1 :   {
        type:String,
        required:true
    }
    ,
    front_shaft_runout_k3_2 :   {
        type:String,
        required:true
    }
    ,
    front_shaft_runout_k3_3 :   {
        type:String,
        required:true
    }
    ,
    journal_1_outer_diameter_runout_k3 :   {
        type:String,
        required:true
    }
    ,
    rr_axis_runout_k3 :   {
        type:String,
        required:true
    }
    ,
    rr_flange_outer_diameter_runout_k4 :   {
        type:String,
        required:true
    },
    
    rear_flange_face_runout_k6 :   {
        type:String,
        required:true
    }
    ,
    j_5_od_runout_k2 :   {
        type:String,
        required:true
    },
    remarksqc1_2_0l:   {
        type:String,
        required:true
    }

})

module.exports = mongoose.model('post_tnga_c_1_2_0ls', PostSchema);