const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    measurer_name: {
        type: String,
        required: true
    },

    process_name: {
        type: String, 
        required: true
    },

    model_name : {
        type:String,
        required:true
    },

    part_serial_name : {
        type:String,
        required:true
    },

    shift : {
        type:String,
        required:true
    },

    balance_correction_hole_appearance : {
        type:String,
        required:true
    },
    keyway_chamfer : {
        type:String,
        required:true
    },

    key_surface :     {
        type:String,
        required:true
    },
    keyway_width :{
        type:String,
        required:true
    },

    key_groove_depth : {
        type:String,
        required:true
    },

    key_groove_position : {
        type:String,
        required:true
    },

    keyway_parallelism : {
        type:String,
        required:true
    },
    key_press_fitting_surface : {
        type:String,
        required:true
    },

    knock_pin_surface : {
        type:String,
        required:true
    },

    knock_pin_press_fitting_surface : {
        type:String,
        required:true
    },

    key_press_height: {
        type:String,
        required:true
    },

    knock_pin_press_fit_height: {
        type:String,
        required:true
    },

    remarksqc6_1_5l:   {
        type:String,
        required:true
    }
   
    
})

module.exports = mongoose.model('post_tnga_c_6_1_5ls', PostSchema);