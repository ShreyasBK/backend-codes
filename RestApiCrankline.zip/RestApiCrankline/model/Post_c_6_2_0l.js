const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    measurer_name: {
        type: String,
        required: true
    },

    process_name: {
        type: String, 
        required: true
    },

    model_name : {
        type:String,
        required:true
    },

    part_serial_name : {
        type:String,
        required:true
    },

    shift : {
        type:String,
        required:true
    },

    balance_correction_hole_appearance : {
        type:String,
        required:true
    },
    keyway_chamfer : {
        type:String,
        required:true
    },

    key_surface :     {
        type:String,
        required:true
    },
    keyway_width_1 :{
        type:String,
        required:true
    },
    keyway_width_2 :{
        type:String,
        required:true
    },

    key_1_groove_depth : {
        type:String,
        required:true
    },

    key_2_groove_depth : {
        type:String,
        required:true
    },

    key_1_groove_position : {
        type:String,
        required:true
    },
    key_2_groove_position: {
        type:String,
        required:true
    },

    keyway_1_parallelism : {
        type:String,
        required:true
    },

    keyway_2_parallelism : {
        type:String,
        required:true
    },

    keyway_relative_position: {
        type:String,
        required:true
    },

    key_press_fitting_surface: {
        type:String,
        required:true
    },
   
    knock_pin_surface:{
        type:String,
        required:true
    },

    knock_pin_press_fitting_surface:{
        type:String,
        required:true
    },

    key_press_height_1:  {
        type:String,
        required:true 
    },
    key_press_height_2:  {
        type:String,
        required:true 
    },

    knock_pin_press_fit_height:  {
        type:String,
        required:true 
    },
    remarksqc6_2_0l:   {
        type:String,
        required:true
    }
    

    
    
})

module.exports = mongoose.model('post_tnga_c_6_2_0ls', PostSchema);