const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    Measurer_Name: {
        type: String,
        required: true
    },

    Process_Name: {
        type: String, 
        required: true
    },

    Model_Name : {
        type:String,
        required:true
    },

    Part_Serial_Name : {
        type:String,
        required:true
    },

    Shift : {
        type:String,
        required:true
    },

    Serial_number_marking_condition : {
        type:String,
        required:true
    },
    Machining_Surface : {
        type:String,
        required:true
    },

    Circularity_Fr_Rr_center_Hole:     {
        type:String,
        required:true
    },
    Position_Fr_center_datum_hole:{
        type:String,
        required:true
    },

    Position_Rr_center_datum_hole: {
        type:String,
        required:true
    },

    Dia_Fr_Axis_1: {
        type:String,
        required:true
    },

    Dia_Fr_Axis_2: {
        type:String,
        required:true
    },

  
   
    Dia_FR_axis_groove:{
        type:String,
        required:true
    },

    FR_Axis_step_Dia:{
        type:String,
        required:true
    },

    J5_Relief_groove_dia:  {
        type:String,
        required:true
    },
    Rear_flange_width :   {
        type:String,
        required:true
    }
    ,
    Fly_wheel_seating_groove_OD :   {
        type:String,
        required:true
    }
    ,
    Fly_wheel_seating_OD :   {
        type:String,
        required:true
    }
    ,
    J_1_end_face_position :   {
        type:String,
        required:true
    }
    ,
    J_1_front_face_position :   {
        type:String,
        required:true
    },
    J_1_RR_side_end_face_position :   {
        type:String,
        required:true
    }
    ,
    J1_OD :   {
        type:String,
        required:true
    }
    ,
    Rear_flane_dia :   {
        type:String,
        required:true
    }
    ,
    Phase_ref_plane_position_datum :   {
        type:String,
        required:true
    }
    ,
    Front_face_center_hole_datum_dia_to_part_datum_distance :   {
        type:String,
        required:true
    }
    ,
    Rear_face_center_hole_datum_dia_to_part_datum_distance :   {
        type:String,
        required:true
    }
    ,
    FR_end_face_to_FW_fitting_face_length :   {
        type:String,
        required:true
    }
    ,
    Front_shaft_runout_1 :   {
        type:String,
        required:true
    },
    
    Front_shaft_runout_2 :   {
        type:String,
        required:true
    }
    ,
    FR_axis_step:   {
        type:String,
        required:true
    }
    ,
    
    Journal_1_outer_diameter_runout :   {
        type:String,
        required:true
    },

    RR_axis_runout :   {
        type:String,
        required:true
    },

    Rr_Flange_outer_diameter_runout :   {
        type:String,
        required:true
    },

    Rear_flange_face_runout :   {
        type:String,
        required:true
    },

    J4_OD_runout:   {
        type:String,
        required:true
    },

    remarksqc1_1_5l:   {
        type:String,
        required:true
    }


})

module.exports = mongoose.model('post_tnga_c_1_1_5ls', PostSchema);