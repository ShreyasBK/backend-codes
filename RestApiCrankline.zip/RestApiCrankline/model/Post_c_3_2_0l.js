const mongoose = require("mongoose");


const PostSchema = mongoose.Schema({
    measurer_name: {
        type: String,
        required: true
    },

    process_name: {
        type: String, 
        required: true
    },

    model_name : {
        type:String,
        required:true
    },

    part_serial_name : {
        type:String,
        required:true
    },

    shift : {
        type:String,
        required:true
    },

    machined_surface_pin_journal : {
        type:String,
        required:true
    },
    hv_1_j_value : {
        type:String,
        required:true
    },

    hv_2_j_value :     {
        type:String,
        required:true
    },
    hv_3_j_value :{
        type:String,
        required:true
    },

    hv_4_j_value : {
        type:String,
        required:true
    },

    hv_5_j_value : {
        type:String,
        required:true
    },

    pin_1_top_hv_value : {
        type:String,
        required:true
    },
    pin_2_top_hv_value : {
        type:String,
        required:true
    },

    pin_3_top_hv_value : {
        type:String,
        required:true
    },

    pin_4_top_hv_value : {
        type:String,
        required:true
    },

    pin_1_bottom_hv_value: {
        type:String,
        required:true
    },

    pin_2_bottom_hv_value: {
        type:String,
        required:true
    },
   
    pin_3_bottom_hv_value:{
        type:String,
        required:true
    },

    pin_4_bottom_hv_value:{
        type:String,
        required:true
    },

    journal_2_4_width_1:  {
        type:String,
        required:true 
    },

    journal_2_4_width_2:  {
        type:String,
        required:true 
    },

    journal_3_width:  {
        type:String,
        required:true 
    },

    pin_1_width :   {
        type:String,
        required:true
    }
    ,
    pin_2_width :   {
        type:String,
        required:true
    }
    ,
    pin_3_width:   {
        type:String,
        required:true
    }
    ,
    pin_4_width:   {
        type:String,
        required:true
    }
    ,

    journal_1st_hardening_range :   {
        type:String,
        required:true
    }
    ,
    hardening_1_j_range :   {
        type:String,
        required:true
    }
    ,
    hardening_2_j_range :   {
        type:String,
        required:true
    }
    ,
    hardening_3_j_range:   {
        type:String,
        required:true
    }
    ,
    hardening_4_j_range :   {
        type:String,
        required:true
    }
    ,
    hardening_5_j_range :   {
        type:String,
        required:true
    }
    ,

    journal_5th_non_hardening_range :   {
        type:String,
        required:true
    }
    ,
    hardening_1_p_range :   {
        type:String,
        required:true
    }
    ,
    hardening_2_p_range :   {
        type:String,
        required:true
    }
    ,
    hardening_3_p_range :   {
        type:String,
        required:true
    }
    ,
    hardening_4_p_range :   {
        type:String,
        required:true
    }
    ,

    journal_1_outer_diameter_runout_after_hardening :   {
        type:String,
        required:true
    }
    ,
    journal_2_outer_diameter_runout_after_hardening :   {
        type:String,
        required:true
    }
    ,
    journal_3_outer_diameter_runout_after_hardening :   {
        type:String,
        required:true
    }
    ,
    journal_4_outer_diameter_runout_after_hardening :   {
        type:String,
        required:true
    }
    ,
    journal_5_outer_diameter_runout_after_hardening :   {
        type:String,
        required:true
    }
    ,
    hardening_crack :   {
        type:String,
        required:true
    },

    remarksqc3_2_0l:   {
        type:String,
        required:true
    }

})

module.exports = mongoose.model('post_tnga_c_3_2_0ls', PostSchema);